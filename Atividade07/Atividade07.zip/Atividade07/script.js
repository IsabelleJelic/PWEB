while(true){
    PC = "";
    Você = prompt("Escolha entre pedra, papel ou tesoura").toLocaleLowerCase();
    numero = Math.floor(Math.random() * 3);

    if(numero == 0){
        PC = "pedra"
    } 
    else if(numero == 1){
        PC = "papel"
    } 
    else {
        PC = "tesoura"
    }

    
    if(Você == "pedra" || Você == "papel" || Você == "tesoura"){
        if (Você == "pedra") {
            alert("O PC colocou " + PC );
            if (PC == "tesoura") {
                alert ("Você Ganhou! :)");
            } else if (PC == "papel"){
                alert ("PC Ganhou! :)");
            } else if (PC == "pedra") {
                alert ("Houve um empate! :/");
            }
            
            
        }
        else if (Você == "tesoura") {
            alert("O PC colocou " + PC );
            if (PC == "pedra") {
                alert ("PC Ganhou! :)");
            } else if (PC == "papel"){
                alert ("Você ganhou! :)");
            } else if (PC == "tesoura") {
                alert ("Houve um empate! :/");
            }
        }
        
        
        else  if (Você == "papel"){
            alert("O PC colocou " + PC );
            if (PC == "pedra") {
                alert ("Você Ganhou! :)");
            }else if (PC == "tesoura") {
                alert ("PC Ganhou! :)");
            }else if (PC == "papel")  {
                alert ("Houve um Empate! :/");
            }
            
        }
    }
    else {
        alert("Escolha entre pedra, papel ou tesoura!");
    }
    }
    