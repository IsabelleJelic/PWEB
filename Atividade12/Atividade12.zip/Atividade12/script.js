function abrir(imagem) {
    imagem.src = 'img/janelaaberta.png'
    document.getElementById("text").innerHTML = "Feche a Janela!"
}

function fechar(imagem) {
    imagem.src = 'img/janelafechada.png'
    document.getElementById("text").innerHTML = "Abra a Janela!"
}

function clicar(imagem) {
    imagem.src = 'img/janelaquebra.png'
    document.getElementById("text").innerHTML = "Quebrou a Janela!"
}