function Retangulo(base, altura) {
    this.base = base
    this.altura = altura
  
    function Area(base, altura) {
      return base * altura
    }
  
    this.area = Area(base, altura)
  }
  
  var novo = new Retangulo(10, 20)
  
  alert(novo.area)
  
  
  // Super Classe
  function Conta() {
    var nomeCorrentista;
    var banco;
    var numeroConta;
    var saldo;
  
    // Métodos GET
    this.getNomeCorrentista = function () {
      return nomeCorrentista;
    };
  
    this.getBanco = function () {
      return banco;
    }
  
    this.getNumeroConta = function () {
      return numeroConta;
    }
  
    this.getSaldo = function () {
      return saldo;
    }
  
    // Métodos SET
    this.setNomeCorrentista = function (value) {
      nomeCorrentista = value;
    }
  
    this.setBanco = function (value) {
      banco = value;
    }
  
    this.setNumeroConta = function (value) {
      numeroConta = value;
    }
  
    this.setSaldo = function (value) {
      saldo = value;
    }
  }
  
  // Sub Classe
  function Corrente () {
    var saldoEspecial;
  
    this.getSaldoEspecial = function () {
      return saldoEspecial;
    }
  
    this.setSaldoEspecial = function (value) {
      saldoEspecial = value;
    }
  
  }
  
  function Poupanca () {
    var juros;
    var dataVenc;
  
    this.getJuros = function () {
      return juros;
    }
  
    this.getDataVenc = function () {
      return dataVenc;
    }
  
    this.setJuros = function (value) {
      juros = value;
    }
  
    this.setDataVenc = function (value) {
      dataVenc = value;
    }
  }
  
  Corrente.prototype = new Conta();
  Poupanca.prototype = new Conta();
  
  nContaCorrente = new Corrente();
  nContaPoupanca = new Poupanca();
  
  nContaCorrente.setNomeCorrentista('Nome: Melissa')
  nContaCorrente.setBanco('Banco: Safra')
  nContaCorrente.setNumeroConta(14589)
  nContaCorrente.setSaldo(1250)
  nContaCorrente.setSaldoEspecial(200)
  
  nContaPoupanca.setNomeCorrentista('Nome: Fernanda')
  nContaPoupanca.setBanco('Banco: Santander')
  nContaPoupanca.setNumeroConta(558)
  nContaPoupanca.setSaldo(4500)
  nContaPoupanca.setJuros(5)
  nContaPoupanca.setDataVenc('Data de Vencimento: 13/09/2023')
  
  alert(nContaCorrente.getNomeCorrentista() + '\n' +
        nContaCorrente.getBanco() + '\n' +
        nContaCorrente.getNumeroConta() + '\n' +
        nContaCorrente.getSaldo() + '\n' +
        nContaCorrente.getSaldoEspecial() + '\n'
  )
  
  alert(nContaPoupanca.getNomeCorrentista() + '\n' +
        nContaPoupanca.getBanco() + '\n' +
        nContaPoupanca.getNumeroConta() + '\n' +
        nContaPoupanca.getSaldo() + '\n' +
        nContaPoupanca.getJuros() + '\n' +
        nContaPoupanca.getDataVenc() + '\n'
  )
  
  
  
  