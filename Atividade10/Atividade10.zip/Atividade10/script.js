var aluno1 = new Object();
aluno1.name = ": Luana Paes";
aluno1.RA = " 123321";

alert("\nAluno 1\n Nome" + aluno1.name + "\n RA:" + aluno1.RA);

var aluno2 = {
    name: ": Glória Marquez",
    RA: " 995588"

};
alert("\nAluno 2\nNome" + aluno2.name + "\n RA:" + aluno2.RA);


var aluno3 = {};
aluno3.name = ": Clarice Meireles";
aluno3.RA = " 475621";
alert("\nAluno 3\nNome" + aluno3.name + "\n RA:" + aluno3.RA);