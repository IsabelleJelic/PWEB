function maior() {
    document.getElementById("Menor").checked = false; 
    txt = document.getElementById("campo").value;
    document.getElementById("campo").value = txt.toUpperCase();
  }
  
  function menor() {
    document.getElementById("Maior").checked = false;
    txt = document.getElementById("campo").value;
    document.getElementById("campo").value = txt.toLowerCase();
  }