var otimo = 0, bom = 0, maisidade = 0, menosidade = 99, regular = 0, pessimo = 0, cont = 0, sexo, idade, opiniao, 
media, mulher = 0, homem = 0, soma = 0;

do {
    idade = parseInt(prompt("Digite sua idade: "));
    if (idade > maisidade) {
        maisidade = idade;
    }
    if (idade <= menosidade) {
        menosidade = idade;
    }
    soma = soma + idade;

    sexo = prompt("Digite seu sexo Feminino ou Masculino");
    if (sexo == "F" || sexo == "f") {
        mulher = mulher + 1;
    }
    if (sexo == "M" || sexo == "m") {
        homem = homem + 1;
    }

    opiniao = prompt("\nDigite 1 para péssimo" +
        "\nDigite 2 para regular" +
        "\nDigite 3 para bom" +
        "\nDigite 4 para ótimo");
        if(opiniao == 1){
            pessimo = pessimo + 1;
        }
        if(opiniao == 2){
            regular = regular + 1;
        }
        if(opiniao == 3){
            bom = bom + 1;
        }
        if(opiniao == 4){
            otimo = otimo + 1;
        }

    cont++
} while (cont < 45);

media = soma / 45;
porcentagem = (100 *(bom+otimo)/45);

alert("\nEsse é o resultado da pesquisa:"
+ "\n\nO resultado da media das idades é " + media
+ "\nA pessoa com mais idade tem" + maisidade + " anos"
+ "\nA pessoa com menos idade tem " + menosidade + " anos"
+ "\nEssa foi a quantidade de pessoas que responderam pessimo: " + pessimo
+ "\nEssa foi a porcentagem de pessoas que responderam ótimo e bom: " + porcentagem.toFixed(2) + "%"
+ "\n( "+ mulher +" )"+ " Mulheres responderam" 
+ "\n( "+ homem +" )" + " Homens responderam");