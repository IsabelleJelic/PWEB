
var typed = new typed("span",{
    strings:["Isabelle Jelic","Estudante de Análise e Desenvolvimento de Sistemas."],
    typeSpeed: 70,
    backSpeed: 60,
    loop: true
});
